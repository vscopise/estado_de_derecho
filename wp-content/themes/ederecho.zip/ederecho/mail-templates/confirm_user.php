<html>
    <body>
        <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
            <tr>
                <td style="text-align: center; ">
                    <img src="{{logo_url}}" />
                </td>
            </tr>
            <tr>
                <td style="text-align: center; ">
                    <h2 style="text-align: center">
                        Felicitaciones {{user_name}}
                    </h2>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="text-align: center">
                        Ud. ya está registrado. Puede ingresar al sitio con su nombre de usuario.
                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <h4 style="text-align: center">
                        La contraseña asignada es:
                    </h4>
                    <h4 style="text-align: center">
                        {{user_pass}}
                    </h4>
                    <p style="text-align: center">
                        
                    </p>
                </td>
            </tr>
        </table>
    </body>
</html>