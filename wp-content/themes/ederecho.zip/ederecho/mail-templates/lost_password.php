<html>
    <body>
        <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
            <tr>
                <td style="text-align: center; ">
                    <img src="{{logo_url}}" />
                </td>
            </tr>
            <tr>
                <td style="text-align: center; ">
                    <h4 style="text-align: center">
                        Una nueva contraseña le ha sido asignada:
                    </h4>
                    <h4 style="text-align: center">
                        {{new_pass}}
                    </h4>
                </td>
            </tr>
        </table>
    </body>
</html>